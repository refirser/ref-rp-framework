function LoadPhone(ply)
	ply:LoadPhone()
end
hook.Add("PlayerInitialSpawn", "LoadPhone", LoadPhone)

AddCommand("phonenumber", function(ply, args)
	if IsPolice(ply) then
		if #args > 0 then
			if args[1] ~= "" then
				local target;
				
				for k, v in pairs(player.GetAll()) do
					if string.find(string.upper(v:Nick()), string.upper(args[1])) or string.find(string.upper(v:GetNWString("name")), string.upper(args[1])) then
						target = v;
					end
				end
				
				if IsValid(target) then
					if target:GetNWString("name") ~= "" then
						Notify(ply, target:GetNWString("name") .. " 님의 전화번호", 5)
					else
						Notify(ply, target:Nick() .. " 님의 전화번호", 5)
					end
					Notify(ply, target:GetPhone(), 5)
				end
			end
		end
	else
		send_chat(ply, "경찰들만 이용할 수 있습니다.", Color(255, 0, 0, 255))
	end
end)

AddCommand("call", function(ply, args, text)
	if #args > 0 then
		if args[1] then
			local target;
			
			for k, v in pairs(player.GetAll()) do
				if string.find(v:GetPhone(), args[1]) then
					target = v;
				end
			end
			
			if IsValid(target) then
				if target:GetPhonePower() then
					local text = string.Replace(text, "/call " .. target:GetPhone(), "")
					
					send_chat(ply, target:GetPhone() .. " 번호로 보낸 문자 : " .. text, Color(255, 255, 255, 255))
					send_chat(target, ply:GetPhone() .. " 번호로부터 온 문자 : " .. text, Color(255, 255, 255, 255))
				else
					send_chat(ply, "상대방의 휴대폰이 꺼져있습니다.", Color(255, 0, 0, 255))
				end
			end
		end
	end
end)

AddCommand("phone", function(ply, args)
	if ply:GetPhonePower() then
		ply:SetPhonePower(false)
		Notify(ply, "폰 전원 오프", 3)
	else
		ply:SetPhonePower(true)
		Notify(ply, "폰 전원 온", 3)
	end
end)

AddCommand("추적", function(ply, args)
	if IsPolice(ply) then
		if IsValid(ply:GetTargetPhone()) then
			Notify(ply, "추적을 종료합니다.", 5)
			ply:SetNWEntity("target_phone", NULL)
		end

		if #args > 0 then
			if args[1] then
				local target;
				
				for k, v in pairs(player.GetAll()) do
					if string.find(v:GetPhone(), args[1]) then
						target = v;
					end
				end
				
				if IsValid(target) then
					if target:GetPhonePower() then
						ply:SetTargetPhone(target:GetPhone())
						Notify(ply, "상대방의 폰 번호로 추적을 시작합니다.", 3)
					else
						Notify(ply, "상대방이 전화를 꺼놓아 추적이 불가능합니다.", 3)
					end
				end
			end
		end
	else
		send_chat(ply, "경찰들만 이용할 수 있습니다.", Color(255, 0, 0, 255))
	end
end)