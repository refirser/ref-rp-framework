function DrawPhoneTarget()
	/*if IsValid(LocalPlayer():GetTargetPhone()) then
		if LocalPlayer():GetTargetPhone():GetPhonePower() then
			local dir = (LocalPlayer():GetPos() - LocalPlayer():GetTargetPhone():GetPos()):Angle();
			
			local eyeangles = EyeAngles()

			local camang = EyeAngles3D2D()
			camang:RotateAroundAxis(camang:Up(), math.AngleDifference(dir.yaw, eyeangles.yaw) + 270)
			
			cam.IgnoreZ(true)
			cam.Start3D2D(EyePos3D2DScreen(0, ScrH() - 100), camang, 4)
				draw.SimpleText(">>>", "Gothic_40_Bold", 0, 0, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cam.End3D2D()
			cam.IgnoreZ(false)			
		end
	end*/
end
hook.Add("PostDrawTranslucentRenderables", "DrawPhoneTarget", DrawPhoneTarget)

function DrawPhoneTarget()
	if IsValid(LocalPlayer():GetTargetPhone()) then
		if LocalPlayer():GetTargetPhone():GetPhonePower() then
			if (!LocalPlayer().nextdrawtarget or LocalPlayer().nextdrawtarget <= CurTime()) && (!LocalPlayer().drawtarget or LocalPlayer().drawtarget <= CurTime()) then
				LocalPlayer().nextdrawtarget = CurTime() + 5
				LocalPlayer().drawtarget = CurTime() + 1
			end
			
			if LocalPlayer().drawtarget > CurTime() then
				local pos = LocalPlayer():GetTargetPhone():GetPos():ToScreen()
				LocalPlayer().targetpos = LocalPlayer():GetTargetPhone():GetPos()
					
				draw.SimpleText("목표", "Gothic_24_Bold", pos.x, pos.y, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		else
			if LocalPlayer().targetpos then
				local pos = LocalPlayer().targetpos:ToScreen()
				draw.SimpleText("목표", "Gothic_24_Bold", pos.x, pos.y, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
end
hook.Add("HUDPaint", "DrawPhoneTarget", DrawPhoneTarget)