local meta = FindMetaTable("Player")

function meta:SetPhone(a)
	self:SetNWString("phone", a)
end

function meta:SetPhone(a)
	self:SetNWString("phone", a)
	
	
	local data = util.KeyValuesToTable(file.Read("rf_data/phone.txt", "DATA")) or {}
	if file.Exists("rf_data/phone.txt", "DATA") then
		if !table.HasValue(data, tostring(a)) then
			table.insert(data, tostring(a))
		else
			Notify(self, "폰 번호가 중복되어 변경합니다.", 5)
			self:SetPhone(math.random(0,9) .. math.random(0, 9) .. math.random(0,9) .. math.random(0,9))
			table.insert(data, self:GetPhone())
		end
		file.Write("rf_data/phone.txt", util.TableToKeyValues(data))
	else
		self:SetPhone(math.random(0,9) .. math.random(0, 9) .. math.random(0,9) .. math.random(0,9))
		table.insert(data, self:GetPhone())	
	end
	Notify(self, "번호 : " .. a, 5)

	self:SavePhone()
end

function meta:SavePhone()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	file.Write("rf_data/" .. id .. "/phone.txt", self:GetPhone())
end

function meta:LoadPhone()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.Exists("rf_data/" .. id .. "/phone.txt", "DATA") then
		if !file.IsDir("rf_data", "DATA") then
			file.CreateDir("rf_data")
		end
		
		if !file.IsDir("rf_data/" .. id, "DATA") then
			file.CreateDir("rf_data/" .. id)
		end
		
		self:SetPhone(math.random(0,9) .. math.random(0, 9) .. math.random(0,9) .. math.random(0,9))
	else
		local data = file.Read("rf_data/" .. id .. "/phone.txt", "DATA")
		
		self:SetPhone(data)
	end
end

function meta:SetPhonePower(b)
	self:SetNWBool("phone_power", b)
end

function meta:SetTargetPhone(a)
	local target;
	for k, v in pairs(player.GetAll()) do
		if v:GetPhone() == a then
			target = v;
			break;
		end
	end

	if IsValid(target) then
		self:SetNWEntity("target_phone", target)
	end
end