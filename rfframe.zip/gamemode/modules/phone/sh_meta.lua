local meta = FindMetaTable("Player")

function meta:GetPhone()
	return self:GetNWString("phone")
end

function meta:GetPhonePower()
	return self:GetNWBool("phone_power", true)
end

function meta:GetTargetPhone()
	return self:GetNWEntity("target_phone")
end