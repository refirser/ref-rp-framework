AddCommand("신고", function(ply, args)
	if #args > 0 then
		if args[1] ~= "" then
			local text = string.Replace(text, "/신고 ", "");
		
			for k, v in pairs(player.GetAll()) do
				if v:IsSuperAdmin() or v:IsAdmin() then
					send_chat(v, "[신고]" .. ply:Nick() .. " : " .. text, Color(29, 219, 22))
				end
			end
		end
	end
end)

AddCommand("문의", function(ply, args, text)
	if #args > 0 then
		if args[1] ~= "" then
			local text = string.Replace(text, "/문의 ", "");
		
			for k, v in pairs(player.GetAll()) do
				if v:IsSuperAdmin() or v:IsAdmin() then
					send_chat(v, "[문의]" .. ply:Nick() .. " : " .. text, Color(29, 219, 22))
				end
			end
		end
	end
end)