util.AddNetworkString("send_tutorial")

function player_tutorial(ply)
	ply:LoadTuto()
	ply:SetNoDraw(true)
	timer.Simple(5, function()
		if IsValid(ply) then
			ply:SendLua("OpenTutorial()")		
		end
	end)
	
end
hook.Add("PlayerInitialSpawn", "player_tutorial", player_tutorial)

net.Receive("send_tutorial", function(len, ply)
	local bool = net.ReadBool()
	
	if bool then
		ply:SetNoDraw(false)
		ply:SaveTuto()
		
		if !ply:GetNWBool("char") then
			ply:SendLua([[init_char()]])
		end
	else
		ply:Kick("문제를 맞추지 못해 추방당하였습니다.")
	end
end)