function OpenTutorial()
	if !LocalPlayer():GetNWBool("tutorial") then
		LocalPlayer().nexttuto = CurTime() + 10
		local page = 1;
		local main = vgui.Create("DFrame")
			main:SetSize(700, 500)
			main:SetTitle("")
			main:SetDraggable(false)
			main:ShowCloseButton(false)
			main:MakePopup()
			main:Center()
		function main:Paint(w,h)	
			util.CreateGUIBlur(self, 3, 230)
			
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 230))
			
			draw.SimpleText("튜토리얼", "Gothic_32_Bold", w/2, 5, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			
			if LocalPlayer().nexttuto && LocalPlayer().nexttuto > CurTime() then
				draw.SimpleText("다음으로 넘기기까지 : " .. math.Round(LocalPlayer().nexttuto - CurTime()), "Gothic_24_Bold", w/2, h - 28, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			
			else
				draw.SimpleText("넘기기 가능", "Gothic_24_Bold", w/2, h - 28, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			end
			
			draw.SimpleText(page .. "/" .. #TUTORIAL, "Gothic_24_Bold", w/2, h - 57, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		end
		
		local scroll = vgui.Create("DScrollPanel", main)
			scroll:SetSize(main:GetWide()-10, main:GetTall() - 107)
			scroll:SetPos(5, 42)
		function scroll:Paint(w,h)
		
		end
		
		local bar = scroll:GetVBar();
		bar:SetWide(2);
		function bar.btnUp:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		function bar.btnDown:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		function bar.btnGrip:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		
		local list = vgui.Create("DIconLayout", scroll)
			list:SetSize(scroll:GetWide(), scroll:GetTall())
			list:SetPos(0,0)
			list:SetSpaceY(5)
		function list:Paint(w,h)

		end
		
		local txttable = string.Explode("\n", TUTORIAL[page])

		for k, v in pairs(txttable) do
			local text = list:Add("DPanel")
				text:SetSize(list:GetWide(), 30)
				text:SetPos(0,0)
			function text:Paint(w,h)
				draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		
		local next = vgui.Create("DButton", main)
			next:SetText("")
			next:SetSize(30, 30)
			next:SetPos(main:GetWide() - 30, main:GetTall()/2 - 15)
		function next:OnCursorEntered()
			self.cursor = true
		end
		function next:OnCursorExited()
			self.cursor = false
		end
		function next:Paint(w,h)
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText(">", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		function next:DoClick()
			if page < #TUTORIAL then
				if LocalPlayer().nexttuto && LocalPlayer().nexttuto <= CurTime() then
					page = page + 1
					for k, v in pairs(list:GetChildren()) do
						v:Remove()
					end
					
					local txttable = string.Explode("\n", TUTORIAL[page])

					for k, v in pairs(txttable) do
						local text = list:Add("DPanel")
							text:SetSize(list:GetWide(), 30)
							text:SetPos(0,0)
						function text:Paint(w,h)
							draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end
					end
					LocalPlayer().nexttuto = CurTime() + 6
				end

			end
		end	
			
		local prev = vgui.Create("DButton", main)
			prev:SetText("")
			prev:SetSize(30, 30)
			prev:SetPos(0, main:GetTall()/2 - 15)
		function prev:OnCursorEntered()
			self.cursor = true
		end
		function prev:OnCursorExited()
			self.cursor = false
		end
		function prev:Paint(w,h)
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText("<", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		function prev:DoClick()
			if page > 1 then
				page = page - 1
				for k, v in pairs(list:GetChildren()) do
					v:Remove()
				end
				
				local txttable = string.Explode("\n", TUTORIAL[page])

				for k, v in pairs(txttable) do
					local text = list:Add("DPanel")
						text:SetSize(list:GetWide(), 30)
						text:SetPos(0,0)
					function text:Paint(w,h)
						draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
			end
		end	
		
		local close = vgui.Create("DButton", main)
			close:SetText("")
			close:SetSize(30, 30)
			close:SetPos(main:GetWide() - 30, 0)
		function close:OnCursorEntered()
			self.cursor = true
		end
		function close:OnCursorExited()
			self.cursor = false
		end
		function close:Paint(w,h)
			if page >= #TUTORIAL then
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText("X", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		function close:DoClick()
			if page >= #TUTORIAL then
				main:Remove()
			
				local main = vgui.Create("DFrame")
					main:SetSize(700, 500)
					main:SetTitle("")
					main:SetDraggable(false)
					main:ShowCloseButton(false)
					main:MakePopup()
					main:Center()
				function main:Paint(w,h)	
					util.CreateGUIBlur(self, 3, 230)
					
					draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 230))
					
					draw.SimpleText("문제 맞추기", "Gothic_32_Bold", w/2, 5, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
				end
				
				local scroll = vgui.Create("DScrollPanel", main)
					scroll:SetSize(main:GetWide()-10, main:GetTall() - 47)
					scroll:SetPos(5, 42)
				function scroll:Paint(w,h)
				
				end
				
				local bar = scroll:GetVBar();
				bar:SetWide(2);
				function bar.btnUp:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end
				function bar.btnDown:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end
				function bar.btnGrip:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end		
				
				local list = vgui.Create("DIconLayout", scroll)
					list:SetSize(scroll:GetWide(), scroll:GetTall())
					list:SetPos(0,0)
					list:SetSpaceY(5)
				function list:Paint(w,h)
				
				end		
				
				local quiz_1;
				
				local quiz_1_label = list:Add("DPanel")
					quiz_1_label:SetPos(0, 0)
					quiz_1_label:SetSize(list:GetWide(), 30)
				function quiz_1_label:Paint(w,h)
					draw.SimpleText("RP의 의미로 올바른 것은?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_1_answer = list:Add("DComboBox")
					quiz_1_answer:SetPos(0, 0)
					quiz_1_answer:SetSize(list:GetWide(), 30)
					quiz_1_answer:SetValue("답변 선택")
					quiz_1_answer:AddChoice("역할 연기")
					quiz_1_answer:AddChoice("알피지")
					quiz_1_answer:AddChoice("롤 캐쉬")
				function quiz_1_answer:OnSelect(index, value)
					quiz_1 = value
				end
				
				local quiz_2;
				
				local quiz_2_label = list:Add("DPanel")
					quiz_2_label:SetPos(0, 0)
					quiz_2_label:SetSize(list:GetWide(), 30)
				function quiz_2_label:Paint(w,h)
					draw.SimpleText("메타 게이밍이란?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_2_answer = list:Add("DComboBox")
					quiz_2_answer:SetPos(0, 0)
					quiz_2_answer:SetSize(list:GetWide(), 30)
					quiz_2_answer:SetValue("답변 선택")
					quiz_2_answer:AddChoice("ㅋㅋ, ㅎㅎ, ㅇㅇ")
					quiz_2_answer:AddChoice("현실에서 힘으로 불가능한 행동을 하는 행위")
					quiz_2_answer:AddChoice("연속으로 점프하는 행위")
					quiz_2_answer:AddChoice("자신이 살고있는 세계와 관련 된 채팅을 게임 내에서 채팅으로 말하는 행위")
				function quiz_2_answer:OnSelect(index, value)
					quiz_2 = value
				end
				
				local quiz_3;
				
				local quiz_3_label = list:Add("DPanel")
					quiz_3_label:SetPos(0, 0)
					quiz_3_label:SetSize(list:GetWide(), 30)
				function quiz_3_label:Paint(w,h)
					draw.SimpleText("IC의 기준은?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_3_answer = list:Add("DComboBox")
					quiz_3_answer:SetPos(0, 0)
					quiz_3_answer:SetSize(list:GetWide(), 30)
					quiz_3_answer:SetValue("답변 선택")
					quiz_3_answer:AddChoice("RP내 이야기")
					quiz_3_answer:AddChoice("RP외 이야기")
					quiz_3_answer:AddChoice("RP내도 아니며 RP외도 아님")
				function quiz_3_answer:OnSelect(index, value)
					quiz_3 = value
				end
				
				local apply = vgui.Create("DButton", main)
					apply:SetText("")
					apply:SetSize(100, 30)
					apply:SetPos(main:GetWide()/2 - 50, main:GetTall() - 35)
				function apply:OnCursorEntered()
					self.cursor = true
				end
				function apply:OnCursorExited()
					self.cursor = false
				end
				function apply:Paint(w,h)
					if !self.cursor then
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
					else
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
					end
					
					draw.SimpleText("완료", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				function apply:DoClick()
					main:Remove()
					
					if quiz_1 == "역할 연기" && quiz_2 == "ㅋㅋ, ㅎㅎ, ㅇㅇ" && quiz_3 == "RP내 이야기" then
						net.Start("send_tutorial")
							net.WriteBool(true)
						net.SendToServer()
					else
						net.Start("send_tutorial")
							net.WriteBool(false)
						net.SendToServer()			
					end
				end
			end
		end
	end
end

function OpenForceTutorial()
		LocalPlayer().nexttuto = CurTime() + 10
		local page = 1;
		local main = vgui.Create("DFrame")
			main:SetSize(700, 500)
			main:SetTitle("")
			main:SetDraggable(false)
			main:ShowCloseButton(false)
			main:MakePopup()
			main:Center()
		function main:Paint(w,h)	
			util.CreateGUIBlur(self, 3, 230)
			
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 230))
			
			draw.SimpleText("튜토리얼", "Gothic_32_Bold", w/2, 5, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			
			if LocalPlayer().nexttuto && LocalPlayer().nexttuto > CurTime() then
				draw.SimpleText("다음으로 넘기기까지 : " .. math.Round(LocalPlayer().nexttuto - CurTime()), "Gothic_24_Bold", w/2, h - 28, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			
			else
				draw.SimpleText("넘기기 가능", "Gothic_24_Bold", w/2, h - 28, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			end
		end
		
		local scroll = vgui.Create("DScrollPanel", main)
			scroll:SetSize(main:GetWide()-10, main:GetTall() - 77)
			scroll:SetPos(5, 42)
		function scroll:Paint(w,h)
		
		end
		
		local bar = scroll:GetVBar();
		bar:SetWide(2);
		function bar.btnUp:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		function bar.btnDown:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		function bar.btnGrip:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		
		local list = vgui.Create("DIconLayout", scroll)
			list:SetSize(scroll:GetWide(), scroll:GetTall())
			list:SetPos(0,0)
			list:SetSpaceY(5)
		function list:Paint(w,h)

		end
		
		local txttable = string.Explode("\n", TUTORIAL[page])

		for k, v in pairs(txttable) do
			local text = list:Add("DPanel")
				text:SetSize(list:GetWide(), 30)
				text:SetPos(0,0)
			function text:Paint(w,h)
				draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end
		
		local next = vgui.Create("DButton", main)
			next:SetText("")
			next:SetSize(30, 30)
			next:SetPos(main:GetWide() - 30, main:GetTall()/2 - 15)
		function next:OnCursorEntered()
			self.cursor = true
		end
		function next:OnCursorExited()
			self.cursor = false
		end
		function next:Paint(w,h)
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText(">", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		function next:DoClick()
			if page < #TUTORIAL then
				if LocalPlayer().nexttuto && LocalPlayer().nexttuto <= CurTime() then
					page = page + 1
					for k, v in pairs(list:GetChildren()) do
						v:Remove()
					end
					
					local txttable = string.Explode("\n", TUTORIAL[page])

					for k, v in pairs(txttable) do
						local text = list:Add("DPanel")
							text:SetSize(list:GetWide(), 30)
							text:SetPos(0,0)
						function text:Paint(w,h)
							draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end
					end
					LocalPlayer().nexttuto = CurTime() + 10
				end

			end
		end	
			
		local prev = vgui.Create("DButton", main)
			prev:SetText("")
			prev:SetSize(30, 30)
			prev:SetPos(0, main:GetTall()/2 - 15)
		function prev:OnCursorEntered()
			self.cursor = true
		end
		function prev:OnCursorExited()
			self.cursor = false
		end
		function prev:Paint(w,h)
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText("<", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		function prev:DoClick()
			if page > 1 then
				page = page - 1
				for k, v in pairs(list:GetChildren()) do
					v:Remove()
				end
				
				local txttable = string.Explode("\n", TUTORIAL[page])

				for k, v in pairs(txttable) do
					local text = list:Add("DPanel")
						text:SetSize(list:GetWide(), 30)
						text:SetPos(0,0)
					function text:Paint(w,h)
						draw.SimpleText(v, "Gothic_24_Bold", 5, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
			end
		end	
		
		local close = vgui.Create("DButton", main)
			close:SetText("")
			close:SetSize(30, 30)
			close:SetPos(main:GetWide() - 30, 0)
		function close:OnCursorEntered()
			self.cursor = true
		end
		function close:OnCursorExited()
			self.cursor = false
		end
		function close:Paint(w,h)
			if !self.cursor then
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
			else
				draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
			end
			
			draw.SimpleText("X", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		function close:DoClick()
			if page >= #TUTORIAL then
				main:Remove()
			
				local main = vgui.Create("DFrame")
					main:SetSize(700, 500)
					main:SetTitle("")
					main:SetDraggable(false)
					main:ShowCloseButton(false)
					main:MakePopup()
					main:Center()
				function main:Paint(w,h)	
					util.CreateGUIBlur(self, 3, 230)
					
					draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 230))
					
					draw.SimpleText("문제 맞추기", "Gothic_32_Bold", w/2, 5, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
				end
				
				local scroll = vgui.Create("DScrollPanel", main)
					scroll:SetSize(main:GetWide()-10, main:GetTall() - 47)
					scroll:SetPos(5, 42)
				function scroll:Paint(w,h)
				
				end
				
				local bar = scroll:GetVBar();
				bar:SetWide(2);
				function bar.btnUp:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end
				function bar.btnDown:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end
				function bar.btnGrip:Paint(w,h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
				end		
				
				local list = vgui.Create("DIconLayout", scroll)
					list:SetSize(scroll:GetWide(), scroll:GetTall())
					list:SetPos(0,0)
					list:SetSpaceY(5)
				function list:Paint(w,h)
				
				end		
				
				local quiz_1;
				
				local quiz_1_label = list:Add("DPanel")
					quiz_1_label:SetPos(0, 0)
					quiz_1_label:SetSize(list:GetWide(), 30)
				function quiz_1_label:Paint(w,h)
					draw.SimpleText("RP의 의미로 올바른 것은?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_1_answer = list:Add("DComboBox")
					quiz_1_answer:SetPos(0, 0)
					quiz_1_answer:SetSize(list:GetWide(), 30)
					quiz_1_answer:SetValue("답변 선택")
					quiz_1_answer:AddChoice("역할 연기")
					quiz_1_answer:AddChoice("알피지")
					quiz_1_answer:AddChoice("롤 캐쉬")
				function quiz_1_answer:OnSelect(index, value)
					quiz_1 = value
				end
				
				local quiz_2;
				
				local quiz_2_label = list:Add("DPanel")
					quiz_2_label:SetPos(0, 0)
					quiz_2_label:SetSize(list:GetWide(), 30)
				function quiz_2_label:Paint(w,h)
					draw.SimpleText("메타 게이밍이란?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_2_answer = list:Add("DComboBox")
					quiz_2_answer:SetPos(0, 0)
					quiz_2_answer:SetSize(list:GetWide(), 30)
					quiz_2_answer:SetValue("답변 선택")
					quiz_2_answer:AddChoice("ㅋㅋ, ㅎㅎ, ㅇㅇ")
					quiz_2_answer:AddChoice("현실에서 힘으로 불가능한 행동을 하는 행위")
					quiz_2_answer:AddChoice("연속으로 점프하는 행위")
					quiz_2_answer:AddChoice("자신이 살고있는 세계와 관련 된 채팅을 게임 내에서 채팅으로 말하는 행위")
				function quiz_2_answer:OnSelect(index, value)
					quiz_2 = value
				end
				
				local quiz_3;
				
				local quiz_3_label = list:Add("DPanel")
					quiz_3_label:SetPos(0, 0)
					quiz_3_label:SetSize(list:GetWide(), 30)
				function quiz_3_label:Paint(w,h)
					draw.SimpleText("IC의 기준은?", "Gothic_24_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				local quiz_3_answer = list:Add("DComboBox")
					quiz_3_answer:SetPos(0, 0)
					quiz_3_answer:SetSize(list:GetWide(), 30)
					quiz_3_answer:SetValue("답변 선택")
					quiz_3_answer:AddChoice("RP내 이야기")
					quiz_3_answer:AddChoice("RP외 이야기")
					quiz_3_answer:AddChoice("RP내도 아니며 RP외도 아님")
				function quiz_3_answer:OnSelect(index, value)
					quiz_3 = value
				end
				
				local apply = vgui.Create("DButton", main)
					apply:SetText("")
					apply:SetSize(100, 30)
					apply:SetPos(main:GetWide()/2 - 50, main:GetTall() - 35)
				function apply:OnCursorEntered()
					self.cursor = true
				end
				function apply:OnCursorExited()
					self.cursor = false
				end
				function apply:Paint(w,h)
					if !self.cursor then
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 50, 50, 255))
					else
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 255))
					end
					
					draw.SimpleText("완료", "Gothic_24", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				function apply:DoClick()
					main:Remove()
					
					if quiz_1 == "역할 연기" && quiz_2 == "ㅋㅋ, ㅎㅎ, ㅇㅇ" && quiz_3 == "RP내 이야기" then
						net.Start("send_tutorial")
							net.WriteBool(true)
						net.SendToServer()
					else
						net.Start("send_tutorial")
							net.WriteBool(false)
						net.SendToServer()			
					end
				end
			end
		end
end