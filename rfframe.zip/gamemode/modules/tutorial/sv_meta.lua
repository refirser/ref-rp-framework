local meta = FindMetaTable("Player")

function meta:SaveTuto()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	file.Write("rf_data/" .. id .. "/tutorial.txt", "true")
	self:SetNWBool("tutorial", true)
end

function meta:LoadTuto()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. id, "DATA") then
		file.CreateDir("rf_data/" .. id)
	end
	
	if !file.Exists("rf_data/" .. id .. "/tutorial.txt", "DATA") then

	else
		self.tutorial = file.Read("rf_data/" .. id .. "/tutorial.txt", "DATA")
		
		self:SetNWBool("tutorial", tobool(self.tutorial))
	end
end