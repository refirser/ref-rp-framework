function run_view_punch(ply, mv)
	/*if !ply.runview or ply.runview <= CurTime() then
		if mv:KeyDown(IN_FORWARD) or mv:KeyDown(IN_BACK) or mv:KeyDown(IN_MOVELEFT) or mv:KeyDown(IN_MOVERIGHT) then
			ply:ViewPunch(Angle(math.random(-(3 - ply:GetStat("look")*0.5), (3 - ply:GetStat("look")*0.5), math.random(-(3 - ply:GetStat("look")*0.5), (3 - ply:GetStat("look")*0.5)), math.random(-(3 - ply:GetStat("look")*0.5), (3 - ply:GetStat("look")*0.5)))))
			ply.runview = CurTime() + 0.01
		elseif mv:KeyDown(IN_JUMP) then
			ply:ViewPunch(Angle(math.random(-(5 - ply:GetStat("look")*0.5), (5 - ply:GetStat("look")*0.5)), math.random(-(5 - ply:GetStat("look")*0.5), (5 - ply:GetStat("look")*0.5)), math.random(-(5 - ply:GetStat("look")*0.5), (5 - ply:GetStat("look")*0.5))))
			ply.runview = CurTime() + 0.01
		end
	end*/
end
hook.Add("Move", "run_view_punch", run_view_punch)