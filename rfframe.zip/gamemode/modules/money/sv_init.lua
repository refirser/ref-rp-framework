pay = pay or 0;

function Pay()
	if pay <= CurTime() then
		local c = #player.GetAll()

		for k, ply in pairs(player.GetAll()) do
			if JOB[ply:GetJOB()].Salary then 
				ply:AddMoney(JOB[ply:GetJOB()].Salary)
				Notify(ply, "사회 복지 수당이 도착하였습니다. 복지 수당 : " .. JOB[ply:GetJOB()].Salary, 5)
			else
				ply:AddMoney(MONEY_CONFIG.DefaultSalary)
				Notify(ply, "사회 복지 수당이 도착하였습니다. 복지 수당 : " .. MONEY_CONFIG.DefaultSalary, 5)
			end		
		end
		
		pay = CurTime() + MONEY_CONFIG.Time
	end
end
hook.Add("Think", "Pay", Pay)

AddCommand("지불", function(ply, args)
	if #args > 0 then
		local target;
		if args[1] then
			for k, v in pairs(player.GetAll()) do
				if v:GetNWString("name") ~= "" then
					if string.find(string.upper(v:GetNWString("name")), string.upper(args[1])) then
						target = v;
						break;
					end
				end
			end
		end
		
		if args[2] then
			if isnumber(tonumber(args[2])) then
				if IsValid(target) && target:GetPos():Distance(ply:GetPos()) < 300 then
					ply:TakeMoney(tonumber(args[2]))
					target:AddMoney(tonumber(args[2]))
					
					send_chat(ply, target:GetNWString("name") .. " 님에게 " .. args[2] .. " 달러를 지불하였습니다.", Color(255, 255, 255, 255))
					send_chat(target, ply:GetNWString("name") .. " 님이 " .. args[2] .. " 달러를 지불하였습니다.", Color(255, 255, 255, 255))
				else
					send_chat(ply,"거리가 너무 멀거나 유효하지 않습니다.", Color(255, 0, 0, 255))
				end
			end
		end
	end
end)
