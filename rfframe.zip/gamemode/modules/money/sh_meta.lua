local meta = FindMetaTable("Player")

function meta:SetMoney(a)
	self:SetNWInt("money", math.Round(math.max(a, 0)))
end

function meta:GetMoney()
	return self:GetNWInt("money", 0)
end

function meta:AddMoney(a)
	if a < 0 then
		if self:HasMoney(a) then
			self:SetMoney(self:GetMoney() + a)
		else
			return false
		end
	else
		self:SetMoney(self:GetMoney() + a)
	end
end

function meta:TakeMoney(a)
	if self:HasMoney(a) then
		self:SetMoney(self:GetMoney() - a)
	else
		return false
	end
end

function meta:HasMoney(a)
	if self:GetMoney() >= a then
		return true
	else
		return false
	end
end

function meta:canAfford(a)
	return math.floor(a) >= 0 and (self:GetMoney() or 0) - math.floor(a) >= 0
end