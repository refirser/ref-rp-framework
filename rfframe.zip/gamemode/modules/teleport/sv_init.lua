util.AddNetworkString("send_teleport")

function SaveTeleport()
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end

	if !file.IsDir("rf_data/teleport", "DATA") then
		file.CreateDir("rf_data/teleport")
	end
	
	file.Write("rf_data/teleport/" .. game.GetMap() .. ".txt", util.TableToKeyValues((tptable or {})))
end

function LoadTeleport()
	if !file.Exists("rf_data/teleport/" .. game.GetMap() .. ".txt", "DATA") then
		SaveTeleport()
	else
		local data = util.KeyValuesToTable(file.Read("rf_data/teleport/" .. game.GetMap() .. ".txt", "DATA"))
		PrintTable(data)
		for k, v in pairs(data) do
			v.origin = util.StringToType(v.origin, "Vector")
			v.target = util.StringToType(v.target, "Vector")
			
			local ent = ents.Create("obj_teleport")
				ent:SetPos(v.origin)
				ent:Spawn()
				
			local ent = ents.Create("obj_teleport")
				ent:SetPos(v.target)
				ent:Spawn()
		end
		
		tptable = data
	end
end
hook.Add("InitPostEntity", "LoadTeleport", LoadTeleport)

net.Receive("send_teleport", function(len, ply)
	if tptable then
		for k, v in pairs(tptable) do
			if util.StringToType(v.target, "Vector") && util.StringToType(v.origin, "Vector") then
				if util.StringToType(v.origin, "Vector"):Distance(ply:GetPos()) <= 100 then
					ply:SetPos(util.StringToType(v.target, "Vector"))
					break
				end
				
				if util.StringToType(v.target, "Vector"):Distance(ply:GetPos()) <= 100 then
					ply:SetPos(util.StringToType(v.origin, "Vector"))
					break
				end
			end
		end
	end
end)

AddCommand("add_tp", function(ply, args)
	if #args > 0 then
		if args[1] == "a" then
			tptable = tptable or {}
			tptable[#tptable + 1] = {
				["origin"] = tostring(ply:GetPos()),
			}
			local ent = ents.Create("obj_teleport")
				ent:SetPos(ply:GetPos())
				ent:Spawn()
		elseif args[1] == "t" then
			tptable = tptable or {}
			local origin = tptable[#tptable].origin
			tptable[#tptable] = {
				["origin"] = origin,
				["target"] = tostring(ply:GetPos()),
			}
			local ent = ents.Create("obj_teleport")
				ent:SetPos(ply:GetPos())
				ent:Spawn()
			SaveTeleport()
		end
	end
end)
