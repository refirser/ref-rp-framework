function teleport_use(ply, button)
	if button == KEY_F then
		net.Start("send_teleport")
		net.SendToServer()
	end
end
hook.Add("PlayerButtonDown", "teleport_use", teleport_use)