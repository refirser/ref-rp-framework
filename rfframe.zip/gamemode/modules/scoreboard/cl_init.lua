local w, h = ScrW(), ScrH()

if scoreboard ~= nil then
	if scoreboard.main ~= nil then
		if scoreboard.main:IsValid() then
			scoreboard.main:Remove()
		end
	end
end

scoreboard = {} 

function scoreboard.getonlinestaff()
	local count = 0
	for k, v in pairs(player.GetAll()) do
		if v:IsAdmin() then
			count = count + 1
		end
	end
	
	return count
end

function scoreboard.Create()
	scoreboard.init = true
	
	local serverstat = {
		[1] = {
			Name = "온라인 관리자",
			Material = Material("rdarkrp/community.png"),
		},
	}
	
	scoreboard.main = vgui.Create("DFrame")
		scoreboard.main:SetPos(0, 0)
		scoreboard.main:SetSize(w, h)
		scoreboard.main:SetTitle("")
		scoreboard.main:Center()
		scoreboard.main:MakePopup()
		scoreboard.main:SetDraggable(false)
		scoreboard.main:ShowCloseButton(false)
		scoreboard.main.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 100))
			
			util.CreateBlurBackGround(self, 3, 100)
			
			draw.SimpleText(LocalPlayer():Nick(), "Gothic_24", w/2, 100, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			
			draw.RoundedBox(0, 10, 10, 50, 30, Color(180, 180, 180, 255))
			
			draw.RoundedBox(0, 60, 10, 200, 30, Color(0, 0, 0, 150))
			
			draw.RoundedBox(0, w - 80, 10, 70, 30, Color(180, 180, 180, 255))
			
			draw.RoundedBox(0, w - 110, 10, 30, 30, Color(0, 0, 0, 150))
			
			draw.SimpleText("시간", "Gothic_18", 35, 25, Color(100, 100, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText(os.date("%A, %H:%M:%S"), "Gothic_18", 160, 25, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText("온라인", "Gothic_18", w - 45, 25, Color(100, 100, 100, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText(#player.GetAll(), "Gothic_18", w - 95, 25, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText("온라인 플레이어", "Gothic_18", w/2, 140, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText("서버 현황", "Gothic_18", w/2, h - 115, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
	scoreboard.playerlist = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.playerlist:SetPos(5, 160)
		scoreboard.playerlist:SetSize(ScrW()/3 - 10, ScrH()/5 * 3)
		scoreboard.playerlist:SetSpacing(5)
		--scoreboard.playerlist:EnableVerticalScrollbar(true)
		scoreboard.playerlist.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))		
		end
		
	scoreboard.playerlist2 = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.playerlist2:SetPos(5 + ScrW()/3, 160)
		scoreboard.playerlist2:SetSize(ScrW()/3 - 10, ScrH()/5 * 3)
		scoreboard.playerlist2:SetSpacing(5)
		--scoreboard.playerlist:EnableVerticalScrollbar(true)
		scoreboard.playerlist2.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))		
		end
		
	scoreboard.playerlist3 = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.playerlist3:SetPos(5 + ScrW()/3 + ScrW()/3, 160)
		scoreboard.playerlist3:SetSize(ScrW()/3 - 10, ScrH()/5 * 3)
		scoreboard.playerlist3:SetSpacing(5)
		--scoreboard.playerlist:EnableVerticalScrollbar(true)
		scoreboard.playerlist3.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))		
		end
		
	scoreboard.serverstats1 = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.serverstats1:SetPos(5, scoreboard.main:GetTall() - 101)
		scoreboard.serverstats1:SetSize(ScrW()/3 - 10, 80)
		scoreboard.serverstats1:SetSpacing(2)
		scoreboard.serverstats1.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		
	scoreboard.serverstats2 = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.serverstats2:SetPos(5 + ScrW()/3, scoreboard.main:GetTall() - 101)
		scoreboard.serverstats2:SetSize(ScrW()/3 - 10, 80)
		scoreboard.serverstats2:SetSpacing(2)
		scoreboard.serverstats2.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		
	scoreboard.serverstats3 = vgui.Create("DPanelList", scoreboard.main)
		scoreboard.serverstats3:SetPos(5 + ScrW()/3 + ScrW()/3, scoreboard.main:GetTall() - 101)
		scoreboard.serverstats3:SetSize(ScrW()/3 - 10, 80)
		scoreboard.serverstats3:SetSpacing(2)
		scoreboard.serverstats3.Paint = function(self, w, h)
			--draw.RoundedBox(0, 0, 0, w, h, Color(255, 255, 255, 255))
		end
		
		
		
	local slot_1 = {}
	local slot_2 = {}
	local slot_3 = {}
	local slot_4 = {}
		
	for k, v in pairs(player.GetAll()) do
		if k <= 10 then
		if IsValid(v) then
			table.insert(slot_1, v)
		end
		end
	end
	
	for k, v in pairs(player.GetAll()) do
		if k > 10 && k <= 20 then
		if IsValid(v) then
			table.insert(slot_2, v)
		end
		end
	end
	
	for k, v in pairs(player.GetAll()) do
		if k > 20 && k <= 30 then
		if IsValid(v) then
			table.insert(slot_3, v)
		end		
		end
	end
	
	local Scroll1 = vgui.Create( "DScrollPanel", scoreboard.playerlist )
		Scroll1:Dock(FILL)
		Scroll1:SetPadding(2)
		Scroll1.Paint = function( self, w, h )
			//draw.RoundedBox( 0, 0, 0, w, h, Color( 20, 20, 20, 220) )
		end	
		
    local sbar = Scroll1:GetVBar()
		function sbar:Paint( w, h )

		end
		function sbar.btnUp:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnDown:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnGrip:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255) )
		end
		
	local List = vgui.Create("DIconLayout", Scroll1)
		List:Dock(FILL)
		List:SetSpaceY(5)
		List.Paint = function(self, w, h)
		
		end
		
	for k, v in pairs(slot_1) do
			local player_list = List:Add( "DButton" )
				player_list:SetText("")
				player_list:SetSize(ScrW()/3 - 10, 50)
				player_list:SetPos(0, 0)
				player_list.Paint = function(self, w, h)
					if IsValid(v) then
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 50))				
					
						if v:GetNWString("name") == "" then
							draw.SimpleText("이름 미정", "Gothic_18_Bold", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						else
							draw.SimpleText(v:GetNWString("name"), "Gothic_18", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						end
					end
				end
				player_list.Think = function(self)
					if !IsValid(v) then
						self:Remove()
					end
				end
				
			surface.SetFont("Gothic_18_Bold")
			local tw = surface.GetTextSize(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.")
			
			local player_avatar_button = vgui.Create("DButton", player_list)
				player_avatar_button:SetSize(ScrW()/3 - 10, 50)
				player_avatar_button:SetPos(0, 0)
				player_avatar_button:SetText("")
				player_avatar_button.Paint = function(self, w, h)
					if self.cursor then
						if self.tooltip == nil then
							self.tooltip = vgui.Create("DPanel", scoreboard.main)
								self.tooltip:SetSize(tw + 20, 20)
								self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
								self.tooltip.Paint = function(self, w, h)
									if LocalPlayer():IsAdmin() or LocalPlayer().IsSuperAdmin() then
										draw.RoundedBox(0, 0, 0, w, h, Color(50, 50, 50, 200))
									
									
										draw.SimpleText(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
									end
								end
						else
							self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
						end
					else
						if self.tooltip ~= nil then
							if self.tooltip:IsValid() then
								self.tooltip:Remove()
								self.tooltip = nil
							end
						end
					end
				end
				player_avatar_button.OnCursorEntered = function(self)
					self.cursor = true
				end
				player_avatar_button.OnCursorExited = function(self)
					self.cursor = false
				end
				player_avatar_button.DoClick = function()
					v:ShowProfile()
				end
			local player_avatar = vgui.Create("AvatarImage", player_list)
				player_avatar:SetSize(50, 50)
				player_avatar:SetPos(0, 0)
				player_avatar:SetPlayer(v, 50)
				
			local mute = vgui.Create("DButton", player_list)
				mute:SetPos(player_list:GetWide() - 80, 0)
				mute:SetSize(70, 30)
				mute:SetText("")
				mute.Paint = function(self, w, h)
					if IsValid(v) then
						if !v:IsMuted() then
							draw.SimpleText("차단", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText("차단 해제", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end
				end
				mute.DoClick = function()
					if !v:IsMuted() then
						v:SetMuted(true)
					else
						v:SetMuted(false)
					end
				end
	end
	
	local Scroll2 = vgui.Create( "DScrollPanel", scoreboard.playerlist2 )
		Scroll2:Dock( FILL )
		Scroll2:SetPadding(2)
		Scroll2.Paint = function( self, w, h )
			//draw.RoundedBox( 0, 0, 0, w, h, Color( 20, 20, 20, 220) )
		end	
		
    local sbar = Scroll2:GetVBar()
		function sbar:Paint( w, h )

		end
		function sbar.btnUp:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnDown:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnGrip:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255) )
		end
		
	local List = vgui.Create("DIconLayout", Scroll2)
		List:Dock(FILL)
		List:SetSpaceY(5)
		List.Paint = function(self, w, h)
		
		end
		
	for k, v in pairs(slot_2) do
			local player_list = List:Add( "DButton" )
				player_list:SetText("")
				player_list:SetSize(ScrW()/3 - 10, 50)
				player_list:SetPos(0, 0)
				player_list.Paint = function(self, w, h)
					if IsValid(v) then
						draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 50))				
					
						if v:GetNWString("name") == "" then
							draw.SimpleText("이름 미정", "Gothic_18_Bold", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						else
							draw.SimpleText(v:GetNWString("name"), "Gothic_18", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						end
					end
				end
				player_list.Think = function(self)
					if !IsValid(v) then
						self:Remove()
					end
				end
				
			surface.SetFont("Gothic_18_Bold")
			local tw = surface.GetTextSize(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.")
			
			local player_avatar_button = vgui.Create("DButton", player_list)
				player_avatar_button:SetSize(ScrW()/3 - 10, 50)
				player_avatar_button:SetPos(0, 0)
				player_avatar_button:SetText("")
				player_avatar_button.Paint = function(self, w, h)
					if self.cursor then
						if self.tooltip == nil then
							self.tooltip = vgui.Create("DPanel", scoreboard.main)
								self.tooltip:SetSize(tw + 20, 20)
								self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
								self.tooltip.Paint = function(self, w, h)
									if LocalPlayer():IsAdmin() or LocalPlayer().IsSuperAdmin() then
										draw.RoundedBox(0, 0, 0, w, h, Color(50, 50, 50, 200))
									
									
										draw.SimpleText(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
									end
								end
						else
							self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
						end
					else
						if self.tooltip ~= nil then
							if self.tooltip:IsValid() then
								self.tooltip:Remove()
								self.tooltip = nil
							end
						end
					end
				end
				player_avatar_button.OnCursorEntered = function(self)
					self.cursor = true
				end
				player_avatar_button.OnCursorExited = function(self)
					self.cursor = false
				end
				player_avatar_button.DoClick = function()
					v:ShowProfile()
				end
			local player_avatar = vgui.Create("AvatarImage", player_list)
				player_avatar:SetSize(50, 50)
				player_avatar:SetPos(0, 0)
				player_avatar:SetPlayer(v, 50)
				
			local mute = vgui.Create("DButton", player_list)
				mute:SetPos(player_list:GetWide() - 80, 0)
				mute:SetSize(70, 30)
				mute:SetText("")
				mute.Paint = function(self, w, h)
					if IsValid(v) then
						if !v:IsMuted() then
							draw.SimpleText("차단", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText("차단 해제", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end
				end
				mute.DoClick = function()
					if IsValid(v) then
						if !v:IsMuted() then
							v:SetMuted(true)
						else
							v:SetMuted(false)
						end
					end
				end
	end
	
	local Scroll3 = vgui.Create( "DScrollPanel", scoreboard.playerlist3 )
		Scroll3:Dock(FILL)
		Scroll3:SetPadding(2)
		Scroll3.Paint = function( self, w, h )
			//draw.RoundedBox( 0, 0, 0, w, h, Color( 20, 20, 20, 220) )
		end	
		
    local sbar = Scroll3:GetVBar()
		function sbar:Paint( w, h )

		end
		function sbar.btnUp:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnDown:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255 ) )
		end
		function sbar.btnGrip:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color( 255, 255, 255) )
		end
		
	local List = vgui.Create("DIconLayout", Scroll3)
		List:Dock(FILL)
		List:SetSpaceY(5)
		List.Paint = function(self, w, h)
		
		end
	
	for k, v in pairs(slot_3) do
			local player_list = List:Add( "DButton" )
				player_list:SetText("")
				player_list:SetSize(ScrW()/3 - 10, 50)
				player_list:SetPos(0, 0)
				player_list.Paint = function(self, w, h)
					draw.RoundedBox(0, 0, 0, w, h, Color(255, 0, 0, 50))				
					
						if v:GetNWString("name") == "" then
							draw.SimpleText("이름 미정", "Gothic_18_Bold", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						else
							draw.SimpleText(v:GetNWString("name"), "Gothic_18", 55, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
						end
				end
				player_list.Think = function(self)
					if !IsValid(v) then
						self:Remove()
					end
				end
				
			surface.SetFont("Gothic_18_Bold")
			local tw = surface.GetTextSize(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.")
			
			local player_avatar_button = vgui.Create("DButton", player_list)
				player_avatar_button:SetSize(ScrW()/3 - 10, 50)
				player_avatar_button:SetPos(0, 0)
				player_avatar_button:SetText("")
				player_avatar_button.Paint = function(self, w, h)
					if self.cursor then
						if self.tooltip == nil then
							self.tooltip = vgui.Create("DPanel", scoreboard.main)
								self.tooltip:SetSize(tw + 20, 20)
								self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
								self.tooltip.Paint = function(self, w, h)
									if LocalPlayer():IsAdmin() or LocalPlayer().IsSuperAdmin() then
										draw.RoundedBox(0, 0, 0, w, h, Color(50, 50, 50, 200))
									
									
										draw.SimpleText(v:Nick() .. " 님의 핑은 " .. v:Ping() .. " 입니다.", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
									end
								end
						else
							self.tooltip:SetPos(gui.MouseX() - (tw + 20)/2, gui.MouseY() - 70)
						end
					else
						if self.tooltip ~= nil then
							if self.tooltip:IsValid() then
								self.tooltip:Remove()
								self.tooltip = nil
							end
						end
					end
				end
				player_avatar_button.OnCursorEntered = function(self)
					self.cursor = true
				end
				player_avatar_button.OnCursorExited = function(self)
					self.cursor = false
				end
				player_avatar_button.DoClick = function()
					v:ShowProfile()
				end
			local player_avatar = vgui.Create("AvatarImage", player_list)
				player_avatar:SetSize(50, 50)
				player_avatar:SetPos(0, 0)
				player_avatar:SetPlayer(v, 50)
				
			local mute = vgui.Create("DButton", player_list)
				mute:SetPos(player_list:GetWide() - 80, 0)
				mute:SetSize(70, 30)
				mute:SetText("")
				mute.Paint = function(self, w, h)
					if IsValid(v) then
						if !v:IsMuted() then
							draw.SimpleText("차단", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText("차단 해제", "Gothic_18_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end
				end
				mute.DoClick = function()
					if IsValid(v) then
						if !v:IsMuted() then
							v:SetMuted(true)
						else
							v:SetMuted(false)
						end
					end
				end
	end
	
	local server_slot1 = {}
	local server_slot2 = {}
	local server_slot3 = {}
	
	for k, v in pairs(serverstat) do
		if #server_slot1 <= #server_slot2 and #server_slot1 <= #server_slot3 then
			table.insert(server_slot1, v)
		elseif #server_slot2 <= #server_slot1 and #server_slot2 <= #server_slot3 then
			table.insert(server_slot2, v)
		elseif #server_slot3 <= #server_slot1 and #server_slot3 <= #server_slot2 then
			table.insert(server_slot3, v)
		end
	end
	
	for k, v in SortedPairs(server_slot1) do
		local stat_list = vgui.Create("DLabel")
			stat_list:SetPos(0, 0)
			stat_list:SetSize(ScrW()/3 - 10, 45)
			stat_list:SetText("")
			stat_list.Paint = function(self, w, h)
				surface.SetMaterial(v.Material)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(0, 0, 40, 40)
			
				draw.RoundedBox(0, 0, 0, w, h, Color(200, 200, 200, 50))
				
				draw.SimpleText(v.Name, "Gothic_16", 45, 7, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				if k == 1 then
					draw.SimpleText(scoreboard.getonlinestaff(), "Gothic_12", 45, 25, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				end
			end
			
		scoreboard.serverstats1:AddItem(stat_list)
	end
	
	for k, v in SortedPairs(server_slot2) do
		local stat_list = vgui.Create("DLabel")
			stat_list:SetPos(0, 0)
			stat_list:SetSize(ScrW()/3 - 10, 45)
			stat_list:SetText("")
			stat_list.Paint = function(self, w, h)
				surface.SetMaterial(v.Material)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(0, 0, 40, 40)
			
				draw.RoundedBox(0, 0, 0, w, h, Color(200, 200, 200, 50))
				
				draw.SimpleText(v.Name, "Gothic_16", 45, 7, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				if k == 1 then
					draw.SimpleText(scoreboard.getonlinestaff(), "Gothic_12", 45, 25, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				end
			end
			
		scoreboard.serverstats2:AddItem(stat_list)
	end
	
	for k, v in SortedPairs(server_slot3) do
		local stat_list = vgui.Create("DLabel")
			stat_list:SetPos(0, 0)
			stat_list:SetSize(ScrW()/3 - 10, 45)
			stat_list:SetText("")
			stat_list.Paint = function(self, w, h)
				surface.SetMaterial(v.Material)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(0, 0, 40, 40)
			
				draw.RoundedBox(0, 0, 0, w, h, Color(200, 200, 200, 50))
				
				draw.SimpleText(v.Name, "Gothic_16", 45, 7, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				if k == 1 then
					draw.SimpleText(scoreboard.getonlinestaff(), "Gothic_12", 45, 25, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				end
			end
			
		scoreboard.serverstats3:AddItem(stat_list)
	end
	
	gui.EnableScreenClicker(true)
end

function scoreboard.Remove()
	scoreboard.init = false
	
	if scoreboard.main ~= nil then
		if scoreboard.main:IsValid() then
			scoreboard.main:Remove()
		end
	end
	
	gui.EnableScreenClicker(false)
end

function scoreboard.check()
	return scoreboard.init
end

function GM:ScoreboardShow()
	if !scoreboard.init then
		scoreboard.Create()
	end
end

function GM:ScoreboardHide()
	if scoreboard.check() then
		scoreboard.Remove()
	end
end
