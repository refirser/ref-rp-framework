surface.CreateFont("Gothic_12", {
	font = "Gothic",
	size = 12,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_16", {
	font = "Gothic",
	size = 16,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_16_Bold", {
	font = "GothicBold",
	size = 16,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_18", {
	font = "Gothic",
	size = 18,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_18_Bold", {
	font = "GothicBold",
	size = 16,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_18_R_Bold", {
	font = "GothicBold",
	size = 18,
	weight = 200,
	extended = true,
})


surface.CreateFont("Gothic_20", {
	font = "Gothic",
	size = 20,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_20_Bold", {
	font = "GothicBold",
	size = 20,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_20_R_Bold", {
	font = "GothicBold",
	size = 20,
	weight = 200,
	extended = true,
})


surface.CreateFont("Gothic_24", {
	font = "Gothic",
	size = 24,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_24_Bold", {
	font = "GothicBold",
	size = 24,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_24_R_Bold", {
	font = "GothicBold",
	size = 24,
	weight = 200,
	extended = true,
})

surface.CreateFont("Gothic_28", {
	font = "Gothic",
	size = 28,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_28_Bold", {
	font = "GothicBold",
	size = 28,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_32", {
	font = "Gothic",
	size = 32,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_32_Bold", {
	font = "GothicBold",
	size = 32,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_40", {
	font = "Gothic",
	size = 40,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_40_Bold", {
	font = "GothicBold",
	size = 40,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_42", {
	font = "Gothic",
	size = 42,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_42_Bold", {
	font = "GothicBold",
	size = 42,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_46", {
	font = "Gothic",
	size = 46,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_46_Bold", {
	font = "GothicBold",
	size = 46,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_48", {
	font = "Gothic",
	size = 48,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_48_Bold", {
	font = "GothicBold",
	size = 48,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_50", {
	font = "Gothic",
	size = 50,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_50_Bold", {
	font = "GothicBold",
	size = 50,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_60", {
	font = "Gothic",
	size = 60,
	weight = 400,
	extended = true,
})

surface.CreateFont("Gothic_60_Bold", {
	font = "GothicBold",
	size = 60,
	weight = 400,
	extended = true,
})