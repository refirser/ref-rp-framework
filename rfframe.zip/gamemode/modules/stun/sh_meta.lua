local meta = FindMetaTable("Player")

function meta:SetStun(bool)
	self:SetNWBool("stun", bool)
end

function meta:GetStun()
	return self:GetNWBool("stun")
end

function meta:IsStun()
	if self:GetStun() then
		return true
	else
		return false
	end
end