function Stun(ply, dmg)
	if ply:IsPlayer() then
		local hp = ply:Health() - dmg:GetDamage()
		
		if ply:IsStun() then
			dmg:ScaleDamage(0)
		end
		
		if hp <= 10 then
			dmg:ScaleDamage(0)
			ply:SetHealth(10)
			ply:SetNoDraw(true)
			ply:StripWeapons()
			ply:SetStun(true)
			
			local ragdoll = ents.Create("prop_ragdoll")
				ragdoll:SetPos(ply:GetPos())
				ragdoll:SetModel(ply:GetModel())
				ragdoll:SetNWEntity("owner", ply)	
				ragdoll:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
				ply:SetNWInt("death", CurTime() + 5)		
				ply.ragdoll = ragdoll
		
			ply:SpectateEntity(ragdoll)
			ply:Spectate(OBS_MODE_CHASE)
		elseif dmg:GetDamage() >= 50 then
			dmg:ScaleDamage(0)
			ply:SetNoDraw(true)
			ply:StripWeapons()
			ply:SetStun(true)
			
			local ragdoll = ents.Create("prop_ragdoll")
				ragdoll:SetPos(ply:GetPos())
				ragdoll:SetModel(ply:GetModel())
				ragdoll:SetNWEntity("owner", ply)
				ragdoll:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)				
				ply:SetNWInt("unstun", CurTime() + 90)		
				ply.ragdoll = ragdoll
		
			ply:SpectateEntity(ragdoll)
			ply:Spectate(OBS_MODE_CHASE)	
		end
	end
end
hook.Add("EntityTakeDamage", "Stun", Stun)

function Unstun(ply)
	if ply:GetNWInt("death") ~= 0 then
		if ply:GetNWInt("death") <= CurTime() then
			if IsValid(ply.ragdoll) then
				ply.ragdoll:Remove()
			end
			ply:SetStun(false)
			ply:Kill()
			ply:SetNWInt("death", 0)
			ply:UnSpectate()
			ply:SetNoDraw(false)
		end
	end
	
	if ply:GetNWInt("unstun") ~= 0 then
		if ply:GetNWInt("unstun") <= CurTime() then
			ply:UnSpectate()	
			if IsValid(ply.ragdoll) then
				ply.ragdoll:Remove()
				ply:SetPos(ply.ragdoll:GetPos())	
			end
			ply:SetStun(false)
			ply:SetNWInt("unstun", 0)
		end	
	end
	
	if !ply:IsStun() then
		ply:UnSpectate()
		ply:SetNoDraw(false)
	end
end
hook.Add("PlayerPostThink", "Unstun", Unstun)

function UnStunDeathThink(ply)
	ply:Spawn()
end
hook.Add("PlayerDeathThink", "UnStunDeathThink", UnStunDeathThink)