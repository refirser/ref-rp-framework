
local FFAddons = {}

hook.Add("CalcView", "MoveShake", function(ply, origin, angles, fov, znear, zfar)
	FFAddons.moveShake = FFAddons.moveShake or {}
	FFAddons.moveShake.strength = FFAddons.moveShake.strength or 0
	FFAddons.moveShake.speed = FFAddons.moveShake.speed and (
		FFAddons.moveShake.speed>math.pi*2 and FFAddons.moveShake.speed-math.pi*2 or FFAddons.moveShake.speed
	) or 0
	
	if ply:GetVelocity():Length() > 0 and ply:IsOnGround() then
		FFAddons.moveShake.strength = math.Clamp(ply:GetVelocity():Length()/400, 0, 1)
		FFAddons.moveShake.speed = FFAddons.moveShake.speed+FrameTime()*FFAddons.moveShake.strength^0.5*12
		
		local moveVector = Vector(0, math.sin(FFAddons.moveShake.speed)*0.5, -math.cos(FFAddons.moveShake.speed*2)*0.25)*FFAddons.moveShake.strength
		moveVector:Rotate(ply:GetAngles())
		
		local moveAngle = Angle(math.cos(FFAddons.moveShake.speed*2)*0.5, math.sin(FFAddons.moveShake.speed)*0.5, 0)*FFAddons.moveShake.strength
		
		return {
			origin = origin+moveVector,
			angles = angles+moveAngle,
			fov = fov,
			znear = znear,
			zfar = zfar
		}
	else
		return {
			origin = origin,
			angles = angles,
			fov = fov,
			znear = znear,
			zfar = zfar
		}
	end
end)

hook.Add("HUDPaint", "FollowingCrosshair", function()
	FFAddons.followingCrosshair = FFAddons.followingCrosshair or {}
	FFAddons.followingCrosshair.X = FFAddons.followingCrosshair.X and (
		math.abs(FFAddons.followingCrosshair.X)>0 and
			FFAddons.followingCrosshair.X*(1-FrameTime()*8)
		or FFAddons.followingCrosshair.X
	) or 0
	FFAddons.followingCrosshair.Y = FFAddons.followingCrosshair.Y and (
		math.abs(FFAddons.followingCrosshair.Y)>0 and
			FFAddons.followingCrosshair.Y*(1-FrameTime()*8)
		or FFAddons.followingCrosshair.Y
	) or 0
	FFAddons.followingCrosshair.angle = FFAddons.followingCrosshair.angle or LocalPlayer():EyeAngles()
	
	local currentEyeAngle = LocalPlayer():EyeAngles()
	if currentEyeAngle != FFAddons.followingCrosshair.angle then
		FFAddons.followingCrosshair.angle.yaw = math.abs(FFAddons.followingCrosshair.angle.yaw)
		currentEyeAngle.yaw = math.abs(currentEyeAngle.yaw)
		
		local difference = FFAddons.followingCrosshair.angle-currentEyeAngle
		
		local yawFix = FFAddons.followingCrosshair.X+difference.yaw*(LocalPlayer():EyeAngles().yaw>0 and -1 or 1)*4
		local pitchFix = FFAddons.followingCrosshair.Y+difference.pitch*8
		FFAddons.followingCrosshair.X = math.Clamp(yawFix, -ScrW()/16, ScrW()/16)
		FFAddons.followingCrosshair.Y = math.Clamp(pitchFix, -ScrW()/16, ScrW()/16)
		
		FFAddons.followingCrosshair.angle = LocalPlayer():EyeAngles()
	end
	
	surface.SetDrawColor(255, 128, 128, 255)
	surface.DrawLine(ScrW()/2-24+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y, ScrW()/2+24+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y)
	surface.DrawLine(ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2-24+FFAddons.followingCrosshair.Y, ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2+24+FFAddons.followingCrosshair.Y)
	
	surface.DrawCircle(ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y, 2, 255, 128, 128, 255)
	surface.DrawCircle(ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y, 4, 255, 128, 128, 192)
	surface.DrawCircle(ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y, 8, 255, 128, 128, 128)
	surface.DrawCircle(ScrW()/2+FFAddons.followingCrosshair.X, ScrH()/2+FFAddons.followingCrosshair.Y, 16, 255, 128, 128, 32)
end)