local meta = FindMetaTable("Player")

function meta:SetTex(a)
	self:SetNWInt("tex", a)
end

function meta:AddTex(a)
	self:SetTex(self:GetTex() + a)
end

function meta:TakeTex(a)
	self:SetTex(self:GetTex() - a)
	
	total_tex = total_tex or 0
	total_tex = total_tex + a
end

function meta:GetTex()
	return self:GetNWInt("tex")
end

function meta:SetNonTex(a)
	self:SetNWBool("tex", a)
end

function meta:GetNonTex()
	return self:GetNWBool("tex")
end