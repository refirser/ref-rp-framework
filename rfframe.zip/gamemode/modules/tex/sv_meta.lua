local meta = FindMetaTable("Player")

function meta:SaveTex()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	file.Write("rf_data/" .. id .. "/tex.txt", self:GetTex())
	file.Write("rf_data/" .. id .. "/texnon.txt", tostring(self:GetNonTex()))
end

function meta:LoadTex()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. id, "DATA") then
		file.CreateDir("rf_data/" .. id)
	end
	
	if !file.Exists("rf_data/" .. id .. "/tex.txt", "DATA") then
		self:SaveTex()
	else
		local data = tonumber(file.Read("rf_data/" .. id .. "/tex.txt", "DATA"))
		local data2 = tobool(file.Read("rf_data/" .. id .. "/texnon.txt", "DATA"))
		
		self:SetTex(data)
		self:SetNonTex(data2)
	end
end

function load_tex_ply(ply)
	ply:LoadTex()
end
hook.Add("PlayerInitialSpawn", "load_tex_ply", load_tex_ply)