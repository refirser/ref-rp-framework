player_config = player_config or {}

player_config.spawnpos = Vector(-7021.672852, 3359.574463, 128.031250)
player_config.spawnang = Angle(0, -90, 0)
