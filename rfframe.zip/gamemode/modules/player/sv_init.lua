function player_spawn(ply)
	ply:Give("weapon_fists")
	ply:Give("weapon_pocket")
	ply:Give("weapon_physcannon")
	
	ply:SetPos(player_config.spawnpos)
	ply:SetAngles(player_config.spawnang)
	
	ply:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	
	ply:SetHunger(100)
	ply:SetThirst(100)
	
	ply:SetWalkSpeed(200)
	ply:SetRunSpeed(250)
	
	ply:SetStamina(100)
	
	if !JOB[ply:GetJOB()] then
		ply:SetJOB(1)
	end
	
	if JOB[ply:GetJOB()].GiveWeapon then
		for k, v in pairs(JOB[ply:GetJOB()].Weapons) do
			ply:Give(v)
		end
	end
	
	send_chat(ply, "알피 관련 서버 명령어는 /명령어를 통해 확인할 수 있습니다",Color(228,247,186,255))
end
hook.Add("PlayerSpawn", "player_spawn", player_spawn)

local meta = FindMetaTable("Player")

function meta:SaveTuto()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	file.Write("rf_data/" .. id .. "/tutorial.txt", "true")
end

function meta:LoadTuto()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. id, "DATA") then
		file.CreateDir("rf_data/" .. id)
	end
	
	if !file.Exists("rf_data/" .. id .. "/tutorial.txt", "DATA") then

	else
		self.tutorial = file.Read("rf_data/" .. id .. "/tutorial.txt", "DATA")
		
		self:SetNWBool("tutorial", tobool(self.tutorial))
	end
end

function GM:PlayerCanPickupWeapon( ply, wep )
	if ply:GetJOB() ~= 2 && wep:GetClass() == "vc_wrench" then
		return false
	end
	
	return true
end

function GM:GravGunPunt( ply )
	return false
end

function GM:PlayerConnected()

end

function GM:PlayerEnteredVehicle( ply, veh, role )
	veh:setDoorOwner(ply)
end

local ent = FindMetaTable("Entity")

function ent:setDoorOwner(ply)
	self:SetNWEntity("owner", ply)
end

function ent:getDoorOwner(ply)
	return self:GetNWEntity("owner")
end

function GM:Move(ply, mv)

end