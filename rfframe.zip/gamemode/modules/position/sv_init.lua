local meta = FindMetaTable("Player")

function meta:SavePos()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	local pos = tostring(self:GetPos())
	
	file.Write("rf_data/" .. id .. "/pos.txt", pos)
end

function meta:LoadPos()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. id, "DATA") then
		file.CreateDir("rf_data/" .. id)
	end
	
	if !file.Exists("rf_data/" .. id .. "/pos.txt", "DATA") then
		self:SetPos(Vector(0,0,0))
		self:SavePos()
	else
		local pos = util.StringToType(file.Read("rf_data/" .. id .. "/pos.txt", "DATA"), "Vector")
		
		self:SetPos(pos)
	end
end

function load_pos(ply)
	ply:LoadPos()
end
hook.Add("PlayerInitialSpawn", "load_pos", load_pos)

function save_pos(ply)
	ply:SavePos()
end
hook.Add("PlayerDisconnected", "save_pos", save_pos)