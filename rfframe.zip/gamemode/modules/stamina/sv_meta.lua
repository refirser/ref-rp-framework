local meta = FindMetaTable("Player")

function meta:SetStamina(a)
	self.stamina = math.Round(a)
end

function meta:GetStamina()
	return self.stamina or 0
end

function meta:TakeStamina(a)
	self.stamina = math.Round(self:GetStamina() - a)
end

function meta:AddStamina(a)
	self.stamina = math.Round(self:GetStamina() + a)
end