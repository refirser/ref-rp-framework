function player_move(ply, mv)
	if mv:KeyDown(IN_SPEED) then
		if ply:GetStamina() > 1 then
			ply:TakeStamina(0.1)
			
			if ply:GetRunSpeed() == ply:GetWalkSpeed() then
				ply:SetRunSpeed(250)
			end
			
			ply.regenstam = CurTime() + 10;
		else
			ply:SetRunSpeed(ply:GetWalkSpeed())
		end
	end
end
hook.Add("Move", "player_move", player_move)

function player_think(ply)
	if ply.regenstam then
		if ply.regenstam <= CurTime() then
			ply:AddStamina(0.05)
		end
	end
end
hook.Add("PlayerPostThink", "player_think", player_think)