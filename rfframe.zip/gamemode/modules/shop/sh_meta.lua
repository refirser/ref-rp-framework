local meta = FindMetaTable("Player")

print("meta")

function meta:SetInventory(t)
	self.inv = t
	
	if SERVER then
		timer.Simple(7, function()
			if IsValid(self) then
				net.Start("send_inv")
					net.WriteTable(self:GetInventory())
				net.Send(self)		
			end
		end)

	end
end

function meta:AddInventory(item, category)
	self.inv = self:GetInventory()

	self.inv[#self.inv + 1] = {
		["item"] = item,
		["category"] = category,
	}
	
	if SERVER then
		net.Start("send_inv")
			net.WriteTable(self:GetInventory())
		net.Send(self)
		self:SaveInv()
	end
end

function meta:TakeInventory(index, item, category)
	self.inv = self:GetInventory()
	if self.inv[index] then
		if self.inv[index].item == item && self.inv[index].category == category then
			table.remove(self.inv, index)
		end
	end
	
	if SERVER then
		net.Start("send_inv")
			net.WriteTable(self:GetInventory())
		net.Send(self)
		self:SaveInv()
	end
end

function meta:GetInventory()
	return self.inv or {}
end