util.AddNetworkString("send_shop");
util.AddNetworkString("send_inv");

function LoadInv(ply)
	ply:SetInventory(ply:LoadInv())
end
hook.Add("PlayerInitialSpawn", "LoadInv", LoadInv)

net.Receive("send_shop", function(len, ply)
	local category = net.ReadInt(32);
	local item = net.ReadInt(32);
	
	if ply:GetMoney() >= SHOP[category][item].Price then
		ply:AddInventory(item, category)
		
		ply:TakeMoney(SHOP[category][item].Price)
	end
end)

net.Receive("send_inv", function(len, ply)
	local bool = net.ReadBool();
	local index = net.ReadInt(32);
	
	if bool then
		local item = ply:GetInventory()[index].item 
		local category = ply:GetInventory()[index].category 
		
		if SHOP[category] && SHOP[category][item] then
			if SHOP[category][item].Func then
				SHOP[category][item].Func(ply, item, category, index)
				ply:TakeInventory(index, item, category)
			end
		end
	else
		local item = ply:GetInventory()[index].item 
		local category = ply:GetInventory()[index].category 
		
		if SHOP[category] && SHOP[category][item] then
			if SHOP[category][item].Class then
				local ent = ents.Create(SHOP[category][item].Class)
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
						
						ply:TakeInventory(index, item, category)
					end
			end
		end
		
		
	end
end)

util.AddNetworkString("send_bank");

AddCommand("add_shop", function(ply, args)
	shoptable = shoptable or {}
	shoptable[#shoptable + 1] = tostring(ply:GetPos())
	local ent = ents.Create("obj_shop")
		ent:SetPos(ply:GetPos())
		ent:Spawn()
	save_drug()
end)

AddCommand("상점", function(ply, args)
	if shoptable then
		local bool = false;
		
		for k, v in pairs(shoptable) do
			local pos = util.StringToType(v, "Vector")
			if pos:Distance(ply:GetPos()) <= 200 then
				bool = true;
				break
			end
		end
		
		for k, v in pairs(ents.FindInSphere(ply:GetPos(), 200)) do
			if v:GetClass() == "obj_shop" then
				bool = true;
				break
			end
		end
		
		if bool then
			ply:SendLua([[OpenShop()]])
		else
			send_chat(ply, "근처에 상점 위치가 존재하지 않습니다.", Color(255, 0, 0, 255))
		end
	else
		send_chat(ply, "근처에 상점 위치가 존재하지 않습니다.", Color(255, 0, 0, 255))
	end
end)


function save_shop()
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. game.GetMap(), "DATA") then
		file.CreateDir("rf_data/" .. game.GetMap())
	end
	
	shoptable = shoptable or {}
	file.Write("rf_data/" .. game.GetMap() .. "/shop.txt", util.TableToKeyValues(shoptable))
end

function load_shop()
	if !file.Exists("rf_data/" .. game.GetMap() .. "/shop.txt", "DATA") then
		save_shop()
	else
		local data = util.KeyValuesToTable(file.Read("rf_data/" .. game.GetMap() .. "/shop.txt", "DATA"))
		
		for k, v in pairs(data) do
			v = util.StringToType(v, "Vector")
			
			local ent = ents.Create("obj_shop")
				ent:SetPos(ply:GetPos())
				ent:Spawn()			
		end
		
		shoptable = data
	end
end
hook.Add("InitPostEntity", "load_shop", load_shop)

