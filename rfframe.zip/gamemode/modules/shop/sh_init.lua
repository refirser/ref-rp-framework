CATEGORY_FOOD = 1;
CATEGORY_WEAPON = 2;
CATEGORY_DRUG = 3;

SHOP = {
	[CATEGORY_FOOD] = {
		[1] = {
			Name = "핫도그",
			Model = "",
			Class = "food_base",
			Price = 4,
			Func = function(ply, item, category)
				ply:AddHunger(20)
			end,
		},
		
		[2] = {
			Name = "사과",
			Model = "",
			Class = "food_base",
			Price = 1,
			Func = function(ply, item, category)
				ply:AddHunger(5)
			end,
		},
		
		[3] = {
			Name = "김밥",
			Model = "",
			Class = "food_base",
			Price = 2,
			Func = function(ply, item, category)
				ply:AddHunger(10)
			end,
		},	
		
		[4] = {
			Name = "햄버거",
			Model = "",
			Class = "food_base",
			Price = 4,
			Func = function(ply, item, category)
				ply:AddHunger(20)
			end,
		},
		
		[5] = {
			Name = "과자",
			Model = "",
			Class = "food_base",
			Price = 1,
			Func = function(ply, item, category)
				ply:AddHunger(5)
			end,
		},
	},
	
	[CATEGORY_WEAPON] = {
		[1] = {
			Name = "어썰트 라이플",
			Model = "",
			Class = "gtav_assault_rifle",
			Price = 370,
			Func = function(ply, item, category)
				ply:Give("gtav_assault_rifle")
			end,
		},	
		
		[2] = {
			Name = "방망이",
			Model = "",
			Class = "gtav_baseballbat",
			Price = 6,
			Func = function(ply, item, category)
				ply:Give("gtav_baseballbat")
			end,
		},
		
		[3] = {
			Name = "AP 피스톨",
			Model = "",
			Class = "ap_pistol",
			Price = 230,
			Func = function(ply, item, category)
				ply:Give("ap_pistol")
			end,
		},
		
		[4] = {
			Name = "불펍 라이플",
			Model = "",
			Class = "bullpup_rifle",
			Price = 350,
			Func = function(ply, item, category)
				ply:Give("bullpup_rifle")
			end,
		},
		
		[5] = {
			Name = "카빈 라이플",
			Model = "",
			Class = "gtav_carbine_rifle",
			Price = 400,
			Func = function(ply, item, category)
				ply:Give("gtav_carbine_rifle")
			end,
		},
		
		[6] = {
			Name = "컴뱃 피스톨",
			Model = "",
			Class = "combat_pistol",
			Price = 250,
			Func = function(ply, item, category)
				ply:Give("combat_pistol")
			end,
		},
		
		[7] = {
			Name = "헤비 리볼버",
			Model = "",
			Class = "heavy_revolver",
			Price = 270,
			Func = function(ply, item, category)
				ply:Give("heavy_revolver")
			end,
		},
		
		[8] = {
			Name = "나이프",
			Model = "",
			Class = "gtav_knife",
			Price = 7,
			Func = function(ply, item, category)
				ply:Give("gtav_knife")
			end,
		},
	},
	
	[CATEGORY_DRUG] = {
		[1] = {
			Name = "알코올",
			Model = "",
			Class = "durgz_alcohol",
			Price = 10,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_alcohol")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end			
			end,
		},
		
		[2] = {
			Name = "아스피린",
			Model = "",
			Class = "durgz_aspirin",
			Price = 30,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_aspirin")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end					
			end,
		},
		
		[3] = {
			Name = "코카인",
			Model = "",
			Class = "durgz_cocaine",
			Price = 35,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_cocaine")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end				
			end,
		},
		
		[4] = {
			Name = "헤로인",
			Model = "",
			Class = "durgz_heroine",
			Price = 30,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_heroine")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end					
			end,
		},
		
		[5] = {
			Name = "본드",
			Model = "",
			Class = "durgz_pcp",
			Price = 7,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_pcp")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end			
			end,
		},
		
		[6] = {
			Name = "대마초",
			Model = "",
			Class = "durgz_weed",
			Price = 25,
			Func = function(ply, item, category)
				local ent = ents.Create("durgz_weed")
					if IsValid(ent) then
						ent:SetPos(ply:GetShootPos())
						ent:Spawn()
						ent:SetNWEntity("owner", ply)
						ent:SetNWInt("category", category)
						ent:SetNWInt("item", item)
					end				
			end,
		},
	},
}