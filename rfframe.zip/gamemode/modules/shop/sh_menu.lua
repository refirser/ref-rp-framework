SHOPMENU = SHOPMENU or {}

SHOPMENU = {
	[1] = {
		Name = "상점",
		Func = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
			
			local bool = false;
			
			for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), 200)) do
				if v:GetClass() == "obj_shop" then
					bool = true;
					break
				end
			end
			
			
			if bool then
			if SHOP[CATEGORY_FOOD] then
				for k, v in pairs(SHOP[CATEGORY_FOOD]) do
					local button = parent:Add("DButton")
						button:SetText("")
						button:SetSize(parent:GetWide()/2-2.5, 50)
						button:SetPos(0,0)
					function button:OnCursorEntered()
						self.cursor = true
					end
					function button:OnCursorExited()
						self.cursor = false
					end
					function button:Paint(w,h)
						if self.cursor then
							draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 135, 150))
						else
							draw.RoundedBox(0, 0, 0, w, h, Color(127, 255, 195, 150))
						end
						
						draw.SimpleText(v.Name .. "(" .. v.Price .. " 달러)", "Gothic_32_Bold", 10, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
					function button:DoClick()
						if LocalPlayer():GetMoney() >= v.Price then
							net.Start("send_shop")
								net.WriteInt(CATEGORY_FOOD, 32)
								net.WriteInt(k, 32)
							net.SendToServer()
						end
					end
				end
			end
			end
		end,
		UnFunc = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
		end,
	},
	
	[2] = {
		Name = "밀매",
		Func = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
			
			local bool = false;
			
			for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), 200)) do
				if v:GetClass() == "obj_drug" then
					bool = true;
					break
				end
			end
			
			if bool then
				if SHOP[CATEGORY_DRUG] then
					for k, v in pairs(SHOP[CATEGORY_DRUG]) do
						local button = parent:Add("DButton")
							button:SetText("")
							button:SetSize(parent:GetWide()/2-2.5, 50)
							button:SetPos(0,0)
						function button:OnCursorEntered()
							self.cursor = true
						end
						function button:OnCursorExited()
							self.cursor = false
						end
						function button:Paint(w,h)
							if self.cursor then
								draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 135, 150))
							else
								draw.RoundedBox(0, 0, 0, w, h, Color(127, 255, 195, 150))
							end
							
							draw.SimpleText(v.Name .. "(" .. v.Price .. " 달러)", "Gothic_32_Bold", 10, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end
						function button:DoClick()
							if LocalPlayer():GetMoney() >= v.Price then
								net.Start("send_shop")
									net.WriteInt(CATEGORY_DRUG, 32)
									net.WriteInt(k, 32)
								net.SendToServer()
							end
						end
					end
				end
				
				if SHOP[CATEGORY_WEAPON] then
					for k, v in pairs(SHOP[CATEGORY_WEAPON]) do
						local button = parent:Add("DButton")
							button:SetText("")
							button:SetSize(parent:GetWide()/2-2.5, 50)
							button:SetPos(0,0)
						function button:OnCursorEntered()
							self.cursor = true
						end
						function button:OnCursorExited()
							self.cursor = false
						end
						function button:Paint(w,h)
							if self.cursor then
								draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 135, 150))
							else
								draw.RoundedBox(0, 0, 0, w, h, Color(127, 255, 195, 150))
							end
							
							draw.SimpleText(v.Name .. "(" .. v.Price .. " 달러)", "Gothic_32_Bold", 10, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end
						function button:DoClick()
							if LocalPlayer():GetMoney() >= v.Price then
								net.Start("send_shop")
									net.WriteInt(CATEGORY_WEAPON, 32)
									net.WriteInt(k, 32)
								net.SendToServer()
							end
						end
					end
				end
			end
		end,
		UnFunc = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
		end,
	},
	
	[3] = {
		Name = "인벤토리",
		Func = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
			
			for k, v in pairs(LocalPlayer():GetInventory()) do
				local button = parent:Add("DButton")
					button:SetText("")
					button:SetSize(parent:GetWide()/2-2.5, 50)
					button:SetPos(0,0)
					button:SetMouseInputEnabled(true)
				function button:OnCursorEntered()
					self.cursor = true
				end
				function button:OnCursorExited()
					self.cursor = false
				end
				function button:Paint(w,h)
					if self.cursor then
						draw.RoundedBox(0, 0, 0, w, h, Color(0, 255, 135, 150))
					else
						draw.RoundedBox(0, 0, 0, w, h, Color(127, 255, 195, 150))
					end
						
					draw.SimpleText(SHOP[v.category][v.item].Name, "Gothic_32_Bold", w/2, h/2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				function button:DoClick()

				end
				function button:OnMousePressed(key)
					if key == MOUSE_LEFT then
						net.Start("send_inv")
							net.WriteBool(false)
							net.WriteInt(k, 32)
						net.SendToServer()					
					elseif key == MOUSE_RIGHT then
						net.Start("send_inv")
							net.WriteBool(true)
							net.WriteInt(k, 32)
						net.SendToServer()					
					end
				end
			end
		end,
		UnFunc = function(parent)
			for k, v in pairs(parent:GetChildren()) do
				v:Remove()
			end
		end,
	},
}