local meta = FindMetaTable("Player")

function meta:SaveInv()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.IsDir("rf_data", "DATA") then
		file.CreateDir("rf_data")
	end
	
	if !file.IsDir("rf_data/" .. id, "DATA") then
		file.CreateDir("rf_data/" .. id)
	end
	
	self.inv = self:GetInventory();
	file.Write("rf_data/" .. id .. "/inv.txt", util.TableToKeyValues(self.inv))
end

function meta:LoadInv()
	local id = string.Replace(self:SteamID(), ":", "!")
	
	if !file.Exists("rf_data/" .. id .. "/inv.txt", "DATA") then
		self:SaveInv()
	else
		self:SetInventory(util.KeyValuesToTable(file.Read("rf_data/" .. id .. "/inv.txt", "DATA")))
	end
end