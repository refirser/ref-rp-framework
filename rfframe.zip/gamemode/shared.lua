GM.Name = "반RP";
GM.Author = "Refirser";
GM.Email = "choh3722@naver.com"
GM.Website = "None"