function ENT:Initialize()
	self:SetModel(self.Model)
end