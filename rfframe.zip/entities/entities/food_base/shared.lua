ENT.PrintName = "Food Base"
ENT.Category = "RF FRAME"
ENT.Model = ""