function ENT:Draw()
	self:DrawModel()
end